<?php

return [

    'authentication_key' => 'AAAAtOVNydc:APA91bElebv0r-hNtNC5uPdPN02uV2ZLhBW6HTf64uHvOOnyIfFUgsTg0FhpmNapOoFa5t6romgBShnNd1_SMDL0r5YR2FBk9EXdFlwns64Z8cyrlv6pTCfKjHUj2rTp01YdjvB_IydE'

];
